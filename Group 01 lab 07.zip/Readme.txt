Please connect to internet before running this MIT Inventory Manager software as the inventory system software is designed to use a central database on a remote server.
The loading time of this software may vary according to the time taken to connect to the database and your internet connection type.
if you need to change the accessing database to a local database,please change the database credentials in the dataAdder class.The SQL query script to configure the database is in the SQL query file.    
 

     Group 01 members
• IM/2019/008 Ashen Shanuka
• IM/2019/023 Tharuka Sandaruwan
• IM/2019/032 Minuli Kannangara
• IM/2019/033 Selvakumar Thakshanah
• IM/2019/067 Isal Laksika
• IM/2019/068 Shiran Maduwantha
• IM/2019/070 Abishan Fernando
• IM/2019/092 Amaya Senarathne
• IM/2019/096 Harini Jayasundara
• IM/2019/110 Thilini Bhagya


