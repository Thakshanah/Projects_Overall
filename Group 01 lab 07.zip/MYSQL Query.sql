CREATE SCHEMA mit_inventory;
USE mit_inventory;
CREATE TABLE `mit_inventory`.`electronic_table` (
  `ItemCode` VARCHAR(10) NOT NULL,
  `ItemName` VARCHAR(50) NULL,
  `Quantity` SMALLINT UNSIGNED NULL,
  PRIMARY KEY (`ItemCode`));
  
CREATE TABLE `mit_inventory`.`furniture_table` (
  `ItemCode` VARCHAR(10) NOT NULL,
  `ItemName` VARCHAR(50) NULL,
  `Quantity` SMALLINT UNSIGNED NULL ,
  PRIMARY KEY (`ItemCode`));
  
  CREATE TABLE `mit_inventory`.`stationary_table` (
  `ItemCode` VARCHAR(10) NOT NULL,
  `ItemName` VARCHAR(50) NULL,
  `Quantity` SMALLINT  UNSIGNED NULL ,
  PRIMARY KEY (`ItemCode`));
  
  