USE `school_management_system`;
INSERT INTO `leave_method`(`name`) VALUES('sick');
INSERT INTO `leave_method`(`name`) VALUES('sick');
INSERT INTO `leave_method`(`name`) VALUES('sick');
INSERT INTO `leave_method`(`name`) VALUES('sick');
INSERT INTO `leave_method`(`name`) VALUES('sick');