USE `school_management_system`;

INSERT INTO `subject`(`subject_name`) VALUES('sinhala');
INSERT INTO `subject`(`subject_name`) VALUES('math');
INSERT INTO `subject`(`subject_name`) VALUES('science');
INSERT INTO `subject`(`subject_name`) VALUES('history');