USE `school_management_system`;
INSERT INTO `position` (`name`) VALUES ('principal');
INSERT INTO `position` (`name`) VALUES ('section head');
INSERT INTO `position` (`name`) VALUES ('cleaning');
INSERT INTO `position` (`name`) VALUES ('deputy principal');
INSERT INTO `position` (`name`) VALUES ('vice principal');