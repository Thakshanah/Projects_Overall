USE `school_management_system`;
INSERT INTO `day`(`name`) VALUES('friday');
INSERT INTO `day`(`name`) VALUES('friday');
INSERT INTO `day`(`name`) VALUES('friday');
INSERT INTO `day`(`name`) VALUES('friday');
INSERT INTO `day`(`name`) VALUES('friday');
