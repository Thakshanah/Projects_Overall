USE `school_management_system`;
INSERT INTO `time_slote`(`start_time`,`end_time`) VALUES('07:30:00','08:10:00');
INSERT INTO `time_slote`(`start_time`,`end_time`) VALUES('07:30:00','08:10:00');
INSERT INTO `time_slote`(`start_time`,`end_time`) VALUES('07:30:00','08:10:00');
INSERT INTO `time_slote`(`start_time`,`end_time`) VALUES('07:30:00','08:10:00');
INSERT INTO `time_slote`(`start_time`,`end_time`) VALUES('07:30:00','08:10:00');
INSERT INTO `time_slote`(`start_time`,`end_time`) VALUES('07:30:00','08:10:00');
INSERT INTO `time_slote`(`start_time`,`end_time`) VALUES('07:30:00','08:10:00');
INSERT INTO `time_slote`(`start_time`,`end_time`) VALUES('07:30:00','08:10:00');