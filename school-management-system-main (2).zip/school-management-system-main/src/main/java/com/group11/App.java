package com.group11;

import com.group11.auth.SignIn;

/**
 * Hello world!
 *
 */
public class App {

    public static void main(String[] args) {
        new SignIn().setVisible(true);
    }
}
