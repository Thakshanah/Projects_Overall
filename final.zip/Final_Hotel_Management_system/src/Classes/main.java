package Classes;

import java.sql.*;
import javax.swing.JOptionPane;

import UI.*;

public class main {

    public static void main(String[] args) {
 
     java.awt.EventQueue.invokeLater(new Runnable() { public void run() { new loginForm().setVisible(true); }});


    }

}
