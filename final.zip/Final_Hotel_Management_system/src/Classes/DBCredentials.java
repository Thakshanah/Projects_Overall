
package Classes;


public class DBCredentials {
    
         //below are default database credentials
    //change below if you need to use a different database.
    
    public static final String username = "root";
    public static final String password = "t00rbada!";
    public static final String connectString = "jdbc:mysql://localhost:3306/hotelmanagementsystem";
    
//        public static final String username = "groopone";
//    public static final String password = "too00Ra2!1";
//    public static final String connectString = "jdbc:mysql://159.223.49.202:2424/hotelmanagementsystem";
    

}
