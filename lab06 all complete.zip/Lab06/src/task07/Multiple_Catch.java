/*
package task07;

public class Multiple_Catch {

    public static void main(String args[]) {
        
        try {
            int array_size = args.length;
            int result = 42 / array_size;
            int new_array[] = {1};
            new_array[90] = 99;
        } 
        
        catch (ArithmeticException e) {
            System.out.println("\n\tDivision by zero.");
            System.out.println("\n\tException: " + e);
        } 
        
        catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array index : " + e);
        }
    }

}

*/

//Answere:

package task07;

public class Multiple_Catch {

    public static void main(String args[]) {
        
        try {
            int array_size = args.length;
            int result = 42 / array_size;
        } 
        
        catch (ArithmeticException e) {
            System.out.println("\n\tDivision by zero.");
            System.out.println("\n\tException: " + e);

            try {
                int new_array[] = {1};
                new_array[90] = 99;
            }
            
            catch (ArrayIndexOutOfBoundsException f) {
                System.out.println("\n\tArray index : " + f);
            }

        }

    }

}