package task06;

public class TestFinally {

    public static void hello() {
        
        try {
            System.out.println("hi");
   System.out.println(5/0);
        } 
        
        catch (RuntimeException e) {
            System.out.println(e);
        } 
        
        finally {  //this block is always get executed even if any exception occured or not
            System.out.println("finally");
        }
    }

    public static void main(String[] args) {
        hello();
    }

}


/*
    Compile and run the following Java programming code and observe the result.
output:
        hi
        finally

    Remove the comment and recompile and run the programming code.What is your observation?
        An exception will occur in the line System.out.println(5/0). it will be caught by the catch block and display the error
        the finally block is executed even any exception caught or not.in here we can see that clearly
output:
        hi
        java.lang.ArithmeticException: / by zero
        finally


*/