package task04;

public class ExceptionMethod {

    public static void main(String args[]) {
        try {
            System.out.println(5 / 0);
        } catch (Exception e) {
            e.printStackTrace();    //prints the exception which can be backtraced in the terminal 
            System.out.println(e.toString());   //print the exception as a string
            System.out.println(e);   //display the exception
            System.out.println(e.getMessage());  // display only the error message part of the exception
        }
        System.out.println("statement 4");
    }

}

/*
State what method would be used by default exception handler internally to inform the exception to the console?
    printStackTrace();

*/