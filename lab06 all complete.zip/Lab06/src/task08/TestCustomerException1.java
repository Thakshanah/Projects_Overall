package task08;

public class TestCustomerException1 {

    public static void validate(int age) throws InvalidAgeException {
        if (age < 18) {
            throw new InvalidAgeException("not valid");
        } 
        
        else {
            System.out.println("welcome to vote");
        }
    }

    public static void main(String args[]) {
        
        try {
            validate(8);
        }
        
        catch (Exception e) {
            System.out.println("Exception occured: " + e);
        }
        
        System.out.println("rest of the code...");
    }
}


/*
Based on your experience of using throw and throws keywords in question 3, question 4 and last
week question 2 & question 7:

(a) Explain the purpose of throw, how and when do we need to use it

    throw keyword is used to throw an exception.in here we are throwing our InvalidAgeException exception.
    the syntax is :
            throw new EXCEPTION_TYPE(ARGUMENTS_IF_ANY);


(b) Explain the purpose of throws, how and when do we need to use it

    throws keyword is used to indicate what is the type of eexception that needed to be thrown from
    a method.the type of the exception is entered following the threos keyword.there are many exception types
    prebuilt to the java(like ArithmeticException,ArrayIndexOutOfBoundsException , etc.)Also we can create our own 
    exception class and indicate it here.In here we have indicated our custom made InvalidAgeException exception class 
    which is derived from the exception super class


*/