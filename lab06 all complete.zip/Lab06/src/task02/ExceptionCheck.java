package task02;

public class ExceptionCheck {

    public static void main(String args[]) {
        try {
            System.out.println("statement 1");
//System.out.println (5/0);
            System.out.println("statement 2");
            System.out.println("statement 3");
            
        } 
        
        catch (ArithmeticException e) { // catch (FileNotFoundException e)
            System.out.println(10 / 2);
System.out.println(10/0);
            System.out.println(e);
        }
        System.out.println("statement 4");
    }

}


/*
What can you say about the termination of the program in following cases?
(a) If no exception in the program,
    code block in the try block will run and then the "statement 4" will be printed.the catch block will
    not run as there are no exceptions.
    

(b) If statement 2 has the exception, (replace statement 2 with System.out.println (5/0);)
    the try block will run untill the replaced statement 2 and then the catch block will execute
    and the statement 4 will be printed at last.

(c) If corresponding catch block is not available, // catch (FileNotFoundException e)
    an exception will be shown that saying there is no catch block.and the programme will not executed.

(d) If the exception occurs at the catch block, (remove comment //System.out.println(10/0);)
    the programme will execute normally without any error occuring as there are no any error in the 
    catch block.then the catch block will not be executed and the last "statement 4" will be printed
    
(e) If the exception occurs at statement 4
    the programme will be terminated displaying the exception message.

*/