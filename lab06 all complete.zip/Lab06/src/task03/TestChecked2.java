
package task03;


import java.io.*;

public class TestChecked2 {

    public static void main(String args[]) throws FileNotFoundException {
        PrintWriter pw = new PrintWriter("ABC.txt");
        pw.println("Hello");
    }
}

/*
    the programme will run and a file called ABC.txt is created in the root directory 
    of the java project files
*/