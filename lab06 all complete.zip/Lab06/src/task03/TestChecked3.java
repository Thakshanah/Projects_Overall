
package task03;


import java.io.*;

public class TestChecked3 {

    public static void main(String args[]) throws FileNotFoundException {
        PrintWriter pw = new PrintWriter("ABC.txt");
        pw.println("Hello");
        System.out.println(10 / 0);
    }
}
/*
    the programme will run till it reaches the System.out.println(10 / 0); line.
    then the exception message will be displayed as below in the output.
    A file called ABC.txt is created in the root directory of the java project files


Exception in thread "main" java.lang.ArithmeticException: / by zero
	at task03.TestChecked3.main(TestChecked3.java:12)
C:\Users\Tharuka Sandaruwan\AppData\Local\NetBeans\Cache\12.5\executor-snippets\run.xml:111: The following error occurred while executing this line:
C:\Users\Tharuka Sandaruwan\AppData\Local\NetBeans\Cache\12.5\executor-snippets\run.xml:68: Java returned: 1
BUILD FAILED (total time: 1 second)

*/