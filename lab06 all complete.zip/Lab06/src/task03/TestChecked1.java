
package task03;


import java.io.*;

public class TestChecked1 {

    public static void main(String args[]) {
        PrintWriter pw = new PrintWriter("ABC.txt");
        pw.println("Hello");
    }
}

/*

the programme will not run and below exception message will be showed.

Exception in thread "main" java.lang.RuntimeException: Uncompilable code - unreported exception java.io.FileNotFoundException; must be caught or declared to be thrown
	at task03.TestChecked1.main(TestChecked1.java:1)
C:\Users\Tharuka Sandaruwan\AppData\Local\NetBeans\Cache\12.5\executor-snippets\run.xml:111: The following error occurred while executing this line:
C:\Users\Tharuka Sandaruwan\AppData\Local\NetBeans\Cache\12.5\executor-snippets\run.xml:68: Java returned: 1
BUILD FAILED (total time: 1 second)
*/