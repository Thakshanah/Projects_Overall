package task01;

import task01.Cake;


public class orderCake extends Cake {
    
    
    public orderCake(String n, double r, double weight) {
		super(n, r);
		this.weight = weight;
	}

    
    public double weight;
    
    @Override
    public double calcPrice() {
        return weight*rate;
    }

    
    
    
}
