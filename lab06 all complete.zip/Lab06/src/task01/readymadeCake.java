/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package task01;

/**
 *
 * @author Tharuka Sandaruwan
 */
public class readymadeCake extends Cake{
    
        public readymadeCake(String n, double r, int quantity) {
		super(n, r);
		this.quantity = quantity;
	}
    
    
    
    public int quantity;
    
    @Override
    public double calcPrice() {
       return rate*quantity;
    }
    
    


    
}
