
package task01;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        
        //  I.	declare an array of 20 cake objects
        Cake cakeArr[] = new Cake[20];
        
        
        //  II.	input data from cake objects and store them into the array
        for(int i = 0; i <  8 ; i ++)
        {
             System.out.println("Enter the name : ");
            String name = scn.next();
            System.out.println("Enter the rate : ");
            double rate = scn.nextDouble();
            System.out.println("Enter the quantity : ");
            int quantity = scn.nextInt();
            readymadeCake newCake = new readymadeCake(name,rate,quantity);
            cakeArr[i] = newCake;
            
        }
        
        for(int i = 8; i <  20 ; i ++)
        {
            System.out.println("Enter the name : ");
            String name = scn.next();       
           System.out.println("Enter the rate : ");
            double rate = scn.nextDouble();
            System.out.println("Enter the weight : ");
            double weight = scn.nextDouble();
            orderCake newCake = new orderCake(name,rate,weight);
             cakeArr[i] = newCake;
           
        }
        
        
        
        //  III. display the total price for all types of cakes
        double max = 0;
        
        Cake maxCake = null ;
        
        double total = 0;
        for (int i = 0; i < 20; i++) {
            if (cakeArr[i].calcPrice() > max) {
                maxCake = cakeArr[i];
            }
            
            total = total + cakeArr[i].calcPrice();
            
        }
        System.out.println("Totlal is : Rs."+total);
        
        

        //  IV.	display the total price and the quantity sold for ready-made cakes
        double readymadeTotal = 0;
        for (int i = 0; i < 20; i++) {
            if (cakeArr[i] instanceof readymadeCake) {
                readymadeTotal = readymadeTotal+cakeArr[i].calcPrice();
            }
        }
        System.out.println("Totlal of readymade is : Rs."+readymadeTotal);
        
        
        
        //  V.	display the information for the cake that has been sold for the highest price
        System.out.println("Cake with highest price is :");
        System.out.println("\tName : "+ maxCake.name+"    Rate : "+maxCake.rate);
    }
}

