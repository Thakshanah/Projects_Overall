
/*
package task05;

public class Multiple_Catch {

    public static void main(String args[]) {
        try {
            int array_size = args.length;
            int result = 42 / array_size;
            int new_array[] = {1};
            
            new_array[90] = 99;
            
        } 
        
        catch (ArithmeticException e) {
            System.out.println("\n\tDivision by zero.");
            System.out.println("\n\tException: " + e);
        } 
        
        catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array index : " + e);
        }
        
    }

}
 */


 /*
(a) How many exceptions are there in the try block?
    two exceptions
    
(b) All exceptions in the try block are captured by catch block?
    no,only the first occuring one will be captured

(c) If all exceptions are not captured, change the program to capture all exceptions.
    please consider the below answere
 */


package task05;

public class Multiple_Catch {

    public static void main(String args[]) {
        
        try {
            int array_size = args.length;
            int result = 42 / array_size;
        } 
        
        catch (ArithmeticException e) {
            System.out.println("\n\tDivision by zero.");
            System.out.println("\n\tException: " + e);

            try {
                int new_array[] = {1};
                new_array[90] = 99;
            }
            
            catch (ArrayIndexOutOfBoundsException f) {
                System.out.println("\n\tArray index : " + f);
            }

        }

    }

}
